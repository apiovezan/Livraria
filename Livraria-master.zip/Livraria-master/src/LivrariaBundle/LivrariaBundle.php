<?php

namespace LivrariaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LivrariaBundle extends Bundle
{
}
